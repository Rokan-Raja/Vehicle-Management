<?php
$con=mysqli_connect("localhost","root","","vehicle_management");
if(!$con)
{
    echo"database not Connected";
}
?>